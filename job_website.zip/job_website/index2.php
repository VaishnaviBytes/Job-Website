<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link rel = "icon" href = "uploaded_images/php.jpg">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>

<body>
    <div class="container mt-3 ">
        <h2 class="text-uppercase text-success text-center">Registration Form</h2>
        <div class="row col-md-12 d-flex justify-content-center">
            <div class="col-md-7 mt-3">
                <form action="insert.php" method="POST" enctype="multipart/form-data"> 
                <div class="mb-3">
                        <label for="fname" class="form-label">First Name </label>
                        <input type="text" class="form-control" name="fname" id="fname" placeholder="Enter Your Name"required>
                    </div>
                    <div class="mb-3">
                        <label for="name" class="form-label">Last Name </label>
                        <input type="text" class="form-control" name="lname" id="lname" placeholder="Enter Your Name"required>
                    </div>
                      <div class="mb-3">
                        <label for="name" class="form-label">Mobile </label>
                        <input type="text" class="form-control" name="mobile" id="mobile" placeholder="Enter Your Mobile"required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email address</label>
                        <input type="email" class="form-control" name="email" id="email" placeholder="Enter Your Email"required>
                    </div>
                  
                    <select class="form-select"  id="gender" name="gender"required>
                        <option selected>Gender</option>
                        <option value="Male">Male </option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                        </select>
                        <div class="mb-3">
                        <label for="file" class="form-label">Upload Resume </label>
                        <input type="file" class="form-control" name="image" id="image">
                    </div>
                     <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" name="password" id="password" placeholder="Enter Your password"required>
                    </div>
                  <div class="text-center">
                  <button type="submit" name="submit" value="submit"  class="btn btn-success btn-lg btn-block" onclick="myFunction()">Register</button>
                  </div>
                </form>
            </div>
        </div>
    </div>
  <div>

</div>
<script>
function myFunction() {
 alert('Register Successfully');
}
</script>
    <script
     src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

    </body>
</html>