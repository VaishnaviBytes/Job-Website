<?php
include("conn.php");
?>
<?php

if(isset($_POST['submit'])){
    $fname=$_POST['fname'];
    $lname=$_POST['lname'];
    $mobile=$_POST['mobile'];
    $email=$_POST['email'];
    $gender=$_POST['gender'];
    // echo $image=$_POST['image'];
    $password=$_POST['password'];
    // echo "<pre>"; 
    // print_r($_FILES);
    // die;
    $upload = $_FILES["image"]["name"];
    $image = $_FILES['image']['tmp_name'];
    $extension = substr($upload, strlen($upload) - 4, strlen($upload));
    $allowed_extensions = array(".jpg", ".jpeg", ".png", ".gif");
    if (!in_array($extension, $allowed_extensions)) {
        echo "<script>alert('Invalid format. Only jpg / jpeg/ png /gif format allowed');</script>";
    } else {

      move_uploaded_file($image, "uploaded_images/" .$upload);
    $sql="INSERT INTO `batch1`(`fname`, `lname`, `mobile`,`email`,`gender`,`image`,`password`) VALUES ('$fname','$lname','$mobile','$email','$gender','$upload','$password')";
    if ($conn->query($sql) === TRUE) {
      echo "New record created successfully";
       header('Location:job_list.php');
    } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
    }
  }
   
//       $sql2="UPDATE `batch1` SET`fname`='',`lname`='[value-3]',`mobile`='[value-4]',`email`='[value-5]',`gender`='[value-6]',`image`='[value-7]',`create_at`='[value-8]',`password`='[value-9]' WHERE 1";
      
}elseif(isset($_POST["update"])){
  $userid =$_POST['user_id'];

  //  echo $userid;
  $fname = $_POST['username'];
  $lname = $_POST['lastname'];
  $phone = $_POST['Phone_no'];
  $email = $_POST['email'];
  $gender = $_POST['gender'];
  $password = $_POST['password'];
  $upload = $_FILES['file']['name'];
  $oldfile = $_POST['upload'];
  $oldpath = "uploaded_images" . "/" . $oldfile;
  $extension = substr($upload, strlen($upload) - 4, strlen($upload));
  $allowed_extensions = array(".jpg", "jpeg", ".png", ".gif");
  if (!empty($_FILES['file']['name'])) {
    if (!in_array($extension, $allowed_extensions)) {
        echo "<script>alert('Invalid format. Only jpg / jpeg/ png /gif format allowed');</script>";
    } else {
        move_uploaded_file($_FILES["file"]["tmp_name"], "uploaded_images/" . $upload);

      $query="UPDATE `batch1` SET `fname`='$fname',`lname`='$lname',`mobile`='$phone',`email`='$email',`gender`='$gender',`image`='$upload',`password`='$password' WHERE id=$userid";
      //  $query = "UPDATE `batch1` SET `fname`='$fname',`lname`='$lname',`email`='$email',`mobile`='$phone',`gender`=' $gender',`password`='$password' WHERE id=$userid";
       if ($conn->query($query) === TRUE) {
            unlink($oldpath);
            echo "Data updated Successfully...";
            header("Location: dashboard.php");
      }
    }
  }
}else{
echo $id=$_GET['id'];
$query="DELETE FROM `batch1` WHERE id=$id";
if ($conn->query($query) === TRUE) {
       
  echo "Data Deleted  Successfully...";
   header("Location: dashboard.php");

}
} 
?>