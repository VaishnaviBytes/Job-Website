<?php
$conn=mysqli_connect("localhost","root","","batch1");
// $servername = "localhost";
// $username = "root";
// $password = "";
// $database="batch1";

// Create connection
// $conn = new mysqli($servername, $username, $password,$database);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
?>