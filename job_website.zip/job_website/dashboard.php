<?php include("conn.php"); ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>update Records</title>
     <link rel = "icon" href = "uploaded_images/laravel.png" type = "image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>
<body>
    <div class="container mt-3">
        <div class="row col-md-12 d-flex justify-content-center">
            <h2 class="text-center text-warning text-uppercase">dashboard</h2>
            <div class="d-flex justify-content-end">
            <a href="index2.php" class="btn btn-primary  btn-sm">ADD</a>
                </div>
            <div class=" mt-1">
                <table class="table table table-success table-striped">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">FirstName</th>
                            <th scope="col">LastName</th>
                            <th scope="col">Mobile</th>
                            <th scope="col">Email</th>
                            <th scope="col">Gender</th>
                            <th scope="col">Image</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $query = "SELECT * FROM batch1";
                        $query_run = mysqli_query($conn, $query);

                        if (mysqli_num_rows($query_run) > 0) {
                            foreach ($query_run as $student) {
                              
                        ?>
                                <tr>
                                    <td><?php echo $student['id']; ?></td>
                                    <td><?= $student['fname']; ?></td>
                                    <td><?= $student['lname']; ?></td>
                                    <td><?= $student['mobile']; ?></td>
                                    <td><?= $student['email']; ?></td>
                                    <td><?= $student['gender']; ?></td>
                                    <td><img src="uploaded_images/<?php echo $student['image'];?>" width="80" height="80"></td>
                                    <td>
                                        <a href="update.php?id=<?= $student['id']; ?>" class="btn btn-success btn-sm">Edit</a>
                                        <a href="insert.php?id=<?= $student['id']; ?>"onclick="myFunction()" class="btn btn-danger btn-sm">Delete</a>
                                    </td>
                                </tr>
                        <?php
                            }
                        } else {
                            echo "<h5> No Record Found </h5>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script>
    function myFunction() {
  alert("You Want Delete");
}
</script>
</script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>

</html>