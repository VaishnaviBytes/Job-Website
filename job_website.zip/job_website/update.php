<?php include("conn.php");?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Update The Records</title>
    <link rel = "icon" href = "uploaded_images/laravel.png" type = "image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>

<body>
    <div class="container mt-3 ">
        <h2 class="text-uppercase text-success text-center">Update Records</h2>
        <div class="row col-md-12 d-flex justify-content-center">
            <div class="col-md-7 mt-3">
            <div class="d-flex justify-content-end">
            <a href="dashboard.php" class="btn btn-warning  btn-sm">Back</a>
                </div>
                <?php
                $id =$_GET['id'];
                $query = "SELECT * FROM Online_batch WHERE  id='$id'";
                $query_run = mysqli_query($conn, $query);
                if (mysqli_num_rows($query_run) > 0) {
                    foreach ($query_run as $user) {
                     
                ?>
                    <form action="insert.php" method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="fname" class="form-label">First Name </label>
                            <input type="hidden" id="user_id" name="user_id" value="<?php echo  $_REQUEST['id']; ?>">
                            <input type="text" class="form-control" name="username" id="username" value="<?= $user['fname']; ?>">
                        </div>
                        <div class="mb-3">
                            <label for="name" class="form-label">Last Name </label>
                            <input type="text" class="form-control" name="lastname" id="lastname" value="<?= $user['lname']; ?>">
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email address</label>
                            <input type="email" class="form-control" name="email" id="email" value="<?= $user['email']; ?>">
                        </div>
                        <div class="mb-3">
                            <label for="name" class="form-label">Mobile </label>
                            <input type="text" class="form-control" name="Phone_no" id="Phone_no" value="<?= $user['mobile']; ?>">
                        </div>
                        <label for="name" class="form-label">Gender </label>
                        <select class="form-select" aria-label="Default select example" id="gender" name="gender" value="<?= $user['gender']; ?>">
                            <option value="Male" <?= $user['gender'] == 'Male' ? ' selected="selected"' : ''; ?>>Male</option>
                            <option value="Female" <?= $user['gender'] == 'Female' ? ' selected="selected"' : ''; ?>>Female</option>
                            <option value="Other" <?= $user['gender'] == 'Other' ? ' selected="selected"' : ''; ?>>Other</option>
                        </select>
                        <div class="mb-3  ">
                            <label for="file" class="form-label">Upload flle </label>
                            <input type="file" class="form-control" name="file" id="file" value="<?= $user['image']; ?>">
                            <img  src="uploaded_images/<?= $user['image']; ?>" height="150" width="150">
                            <input type="hidden" name="upload" id="upload" class="col-xs-3 mt-1 form-control bg-warning text-black" value="<?= $user['image']; ?>" >
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" name="password" id="password" value="<?= $user['password']; ?> ">
                        </div>
                        <div class="text-center">
                            <button type="submit" name="update" value="update" onclick="myFunction()" class="btn btn-success">Update</button>
                        </div>
                    </form>
                <?php
                    }
                } else {
                    echo '<script>alert("No update tha data")</script>';
                }
                ?>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    <!-- <script>
    function myFunction() {
  alert("Data Updated  sucessfully...");
}
</script> -->
</body>